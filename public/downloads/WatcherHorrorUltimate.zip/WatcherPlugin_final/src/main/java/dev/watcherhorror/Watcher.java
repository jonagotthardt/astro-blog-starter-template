package dev.watcherhorror;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Enderman;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.List;
import java.util.Random;

/**
 * Encapsulates a single Watcher entity.  Instead of extending NMS classes this
 * implementation uses the Bukkit API exclusively to maximise compatibility
 * across server versions.  A repeating task drives the Watcher's behaviour
 * including movement, attacking, playing sounds and sending chat messages.
 */
public class Watcher {
    private final Enderman enderman;
    private final BukkitRunnable task;
    private final Random random = new Random();

    /**
     * Spawns a Watcher at the given location and schedules its AI task.
     *
     * @param plugin the plugin instance
     * @param spawnLocation where to spawn the Watcher
     */
    public Watcher(Plugin plugin, Location spawnLocation) {
        // Spawn a vanilla Enderman and customise its properties.
        this.enderman = spawnLocation.getWorld().spawn(spawnLocation, Enderman.class, e -> {
            e.setCustomName(ChatColor.DARK_PURPLE + "The Watcher");
            e.setCustomNameVisible(true);
            e.setSilent(true);
            // Increase the maximum health before setting the current health.
            // Starting with Minecraft 1.21.1 the default Enderman max health is 40,
            // so attempting to set the health above this throws an exception.  We
            // adjust the max health attribute first, then set the health to match.
            e.getAttribute(org.bukkit.attribute.Attribute.GENERIC_MAX_HEALTH).setBaseValue(40.0);
            e.setHealth(40.0);
            e.setRemoveWhenFarAway(false);
        });

        // Define a repeating task that drives the Watcher's behaviour.  It runs
        // once per second to reduce overhead.
        this.task = new BukkitRunnable() {
            @Override
            public void run() {
                if (!enderman.isValid() || enderman.isDead()) {
                    cancel();
                    return;
                }
                updateBehaviour();
            }
        };
        this.task.runTaskTimer(plugin, 20L, 20L);
    }

    /**
     * Applies the Watcher's AI: moves towards players when not looked at,
     * whispers when stared at, attacks at close range and occasionally
     * whispers chat messages.  All effects are purely cosmetic and do not
     * interfere with the base game mechanics beyond dealing damage.
     */
    private void updateBehaviour() {
        Location watcherLoc = enderman.getLocation();
        List<Player> players = watcherLoc.getWorld().getPlayers();
        for (Player player : players) {
            // Skip dead or offline players.
            if (!player.isOnline() || player.isDead()) continue;
            double distance = player.getLocation().distance(watcherLoc);
            // Only act on players within a large radius.  Increasing the radius
            // to 50 blocks makes the Watcher far more aggressive and
            // frightening.
            if (distance > 50) continue;

            boolean hasSight = player.hasLineOfSight(enderman);
            // Move towards the player regardless of whether the player is looking.  If the
            // player is staring at the Watcher, move more deliberately to heighten the
            // tension.  This creates a relentless pursuer that always closes the
            // distance.
            Vector direction = player.getLocation().toVector().subtract(watcherLoc.toVector());
            direction.setY(0);
            if (direction.lengthSquared() > 1.00) {
                // Scale speed: faster when not being looked at, slower when stared at.
                double speed = hasSight ? 0.3 : 0.8;
                direction.normalize().multiply(speed);
                Location newLoc = watcherLoc.clone().add(direction);
                enderman.teleport(newLoc);
                watcherLoc = newLoc;
            }
            // Whisper and send title if the player maintains eye contact.
            if (hasSight) {
                player.playSound(player.getLocation(), Sound.BLOCK_PORTAL_AMBIENT, 0.5f, 0.8f);
                player.sendTitle("§5You should not look at him", "", 10, 40, 10);
            }

            // Attack the player at very close range.  Increase the damage
            // significantly to make the Watcher truly terrifying.
            if (distance <= 2.5) {
                player.damage(20.0, enderman); // deal 10 hearts of damage
                // Spawn a larger particle burst and play a louder scream.
                watcherLoc.getWorld().spawnParticle(
                        Particle.BLOCK,
                        watcherLoc,
                        40,
                        0.5,
                        1,
                        0.5,
                        0.2,
                        Material.REDSTONE_BLOCK.createBlockData()
                );
                watcherLoc.getWorld().playSound(watcherLoc, Sound.ENTITY_ENDERMAN_SCREAM, 1.0f, 0.8f);
                player.sendMessage(ChatColor.DARK_PURPLE + "§lLEAVE THIS WORLD.");
            }

            // Occasionally send random creepy chat messages and play a heartbeat.
            if (random.nextInt(20) == 0) {
                int roll = random.nextInt(8);
                switch (roll) {
                    case 0 -> player.sendMessage(ChatColor.DARK_PURPLE + "§lWhy are you still here?");
                    case 1 -> player.sendMessage(ChatColor.DARK_GRAY + "§oYou don't belong here...");
                    case 2 -> player.sendMessage(ChatColor.RED + "§lHe is coming.");
                    case 3 -> player.sendMessage(ChatColor.GRAY + "§oThere is no escape.");
                    case 4 -> player.sendMessage(ChatColor.DARK_PURPLE + "§oThere are things in the dark you should not see...");
                    case 5 -> player.sendMessage(ChatColor.GRAY + "§7You are not alone.");
                    case 6 -> player.sendMessage(ChatColor.RED + "§cThe Watcher remembers you.");
                    case 7 -> player.sendMessage(ChatColor.LIGHT_PURPLE + "§5He’s closer than you think.");
                }
                player.playSound(player.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 1.0f, 0.9f);
            }
        }
    }

    /**
     * Cancel the AI task and remove the entity from the world.  Called when
     * the plugin is disabled.
     */
    public void despawn() {
        this.task.cancel();
        if (enderman.isValid()) {
            enderman.remove();
        }
    }
}