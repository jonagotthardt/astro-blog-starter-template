package dev.watcherhorror;

import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;

/**
 * Entry point of the WatcherHorrorUltimate plugin.  This class is responsible
 * for registering listeners, creating the boss bar and handling commands.
 */
public class WatcherPlugin extends JavaPlugin {
    /**
     * Keep track of all currently active watchers so they can be cleaned up
     * when the plugin is disabled.  Each watcher manages its own repeating
     * task internally.
     */
    private final List<Watcher> activeWatchers = new ArrayList<>();

    /**
     * A scheduled task that periodically spawns Watchers near players.  This
     * task is started in {@link #onEnable()} and cancelled in {@link #onDisable()}.
     */
    private org.bukkit.scheduler.BukkitTask randomSpawnTask;

    @Override
    public void onEnable() {
        // Create a global boss bar and a listener that blocks quit attempts.
        new WatcherBossBar(this);
        new WatcherBlockQuitListener(this);
        // Prevent the Watcher from randomly teleporting away.  Without this
        // listener, endermen will teleport when taking damage or when in
        // rain.  Cancel the teleport for our custom mob.
        new WatcherTeleportListener(this);

        // Schedule a repeating task that occasionally spawns a Watcher near
        // unsuspecting players.  The task starts after one minute and then
        // runs every five minutes.  For each online player there is a 25%
        // chance that a new Watcher will materialise roughly ten blocks
        // behind them.  This creates the impression that the Watcher is
        // stalking players and observing them from the shadows.
        this.randomSpawnTask = getServer().getScheduler().runTaskTimer(this, () -> {
            for (var player : getServer().getOnlinePlayers()) {
                // Only consider living players in survival or adventure.
                if (!player.isOnline() || player.isDead()) continue;
                if (Math.random() < 0.25) {
                    var loc = player.getLocation();
                    var back = loc.getDirection().multiply(-1);
                    back.setY(0);
                    if (back.lengthSquared() > 0.01) back.normalize();
                    back.multiply(10); // 10 blocks behind
                    var spawnLoc = loc.clone().add(back);
                    // Adjust Y to the top block at that x/z to avoid underground spawns
                    spawnLoc.setY(player.getWorld().getHighestBlockYAt(spawnLoc) + 1);
                    var watcher = new Watcher(this, spawnLoc);
                    activeWatchers.add(watcher);
                }
            }
        }, 20L * 60, 20L * 60 * 5);
        getLogger().info("Watcher Horror plugin aktiviert.");
    }

    @Override
    public void onDisable() {
        // Cancel all watcher tasks and remove the entities.
        if (randomSpawnTask != null) {
            randomSpawnTask.cancel();
        }
        for (Watcher watcher : activeWatchers) {
            watcher.despawn();
        }
        activeWatchers.clear();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (cmd.getName().equalsIgnoreCase("spawnwatcher") && sender instanceof Player player) {
            Location loc = player.getLocation();
            Watcher watcher = new Watcher(this, loc);
            activeWatchers.add(watcher);
            sender.sendMessage("§5Ein Watcher wurde beschworen.");
            return true;
        }
        return false;
    }
}