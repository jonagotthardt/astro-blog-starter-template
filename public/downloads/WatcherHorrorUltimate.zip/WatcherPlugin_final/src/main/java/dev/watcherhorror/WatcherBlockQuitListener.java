package dev.watcherhorror;

import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;

/**
 * Listens for players leaving the server and cancels their quit if a Watcher
 * entity is nearby.  Instead of quitting the player receives a message and
 * everyone online is notified that someone attempted to escape.
 */
public class WatcherBlockQuitListener implements Listener {
    private final Plugin plugin;

    public WatcherBlockQuitListener(Plugin plugin) {
        this.plugin = plugin;
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        // Check if any entity with the custom name "The Watcher" is within
        // 30 blocks of the quitting player.  A null check on the custom
        // name prevents a NullPointerException.
        boolean watcherNearby = player.getWorld().getEntities().stream().anyMatch(e ->
                e.getCustomName() != null && e.getCustomName().contains("The Watcher") &&
                e.getLocation().distanceSquared(player.getLocation()) < 30 * 30);

        if (watcherNearby) {
            // Suppress the quit message so it doesn't clutter chat.
            event.setQuitMessage(null);
            // Schedule a task one tick later to admonish the quitter.  We can't
            // cancel PlayerQuitEvent in Spigot 1.21.1 (it isn't cancellable), so
            // instead we warn the player and notify others just before they leave.
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                player.sendMessage("§4You can't leave...");
                // Use the String-based sound API for custom resource pack sounds. In
                // Spigot 1.21.1 the playSound overload that accepts a string
                // requires a SoundCategory parameter.  MASTER plays the sound to
                // the player's master volume channel.
                player.playSound(player.getLocation(), "watcher.heartbeat", org.bukkit.SoundCategory.MASTER, 1f, 0.8f);
                for (Player p : Bukkit.getOnlinePlayers()) {
                    p.sendMessage("§7Someone tried to escape...");
                }
            }, 1L);
        }
    }
}