package dev.watcherhorror;

import org.bukkit.entity.Enderman;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityTeleportEvent;
import org.bukkit.plugin.Plugin;

/**
 * Cancels teleportation attempts by any Enderman named "The Watcher".  Endermen
 * naturally teleport when taking damage or standing in certain conditions; to
 * keep the Watcher anchored in one place this listener intercepts and
 * cancels those teleports.  Without this, the mob would frequently
 * disappear and undermine the horror atmosphere.
 */
public class WatcherTeleportListener implements Listener {
    public WatcherTeleportListener(Plugin plugin) {
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    @EventHandler
    public void onEntityTeleport(EntityTeleportEvent event) {
        if (event.getEntity() instanceof Enderman ender) {
            String name = ender.getCustomName();
            if (name != null && name.contains("The Watcher")) {
                event.setCancelled(true);
            }
        }
    }
}