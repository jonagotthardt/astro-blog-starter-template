package dev.watcherhorror;

import org.bukkit.Bukkit;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

/**
 * Displays a persistent boss bar to all players indicating the Watcher's
 * presence.  The bar is periodically refreshed to ensure new players see it
 * automatically.  It does not convey health but acts as an atmospheric
 * element.
 */
public class WatcherBossBar {
    private final BossBar bar;

    public WatcherBossBar(Plugin plugin) {
        this.bar = Bukkit.createBossBar("§4✦ He watches your soul ✦", BarColor.PURPLE, BarStyle.SEGMENTED_20);
        this.bar.setVisible(true);
        // Run a repeating task to add all online players to the bar every few
        // seconds.  This avoids having to listen for individual join events.
        new BukkitRunnable() {
            @Override
            public void run() {
                for (Player p : Bukkit.getOnlinePlayers()) {
                    bar.addPlayer(p);
                }
            }
        }.runTaskTimer(plugin, 0L, 60L);
    }
}