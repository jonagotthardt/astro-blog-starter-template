# WatcherHorrorUltimate

WatcherHorrorUltimate is a lightweight horror‑themed plugin for Spigot/Paper 1.21.1.
It spawns an ominous Enderman called **The Watcher** that stalks players, speaks
randomly in chat, plays creepy sounds and punishes anyone who tries to
disconnect while it is nearby.  This project grew out of an abandoned
prototype and has been restructured so that it can be built with Maven and run
on a modern Minecraft server without any native (NMS) code.

## Features

The plugin exposes a single command and takes care of the rest:

* `/spawnwatcher` – Spawns **The Watcher** at the command sender's location.
* The Watcher slowly shambles towards players that are within 20 blocks and
  not looking at it.  When you look away it will close the distance; when you
  stare it down it whispers unnervingly instead.
* When a player gets within striking distance the Watcher deals damage,
  spawns a small blood particle burst and plays a scream sound.
* A global boss bar titled “He watches your soul” is displayed to all
  players to heighten the tension.
* Players cannot log out while the Watcher is nearby – attempting to do so
  results in a creepy message and an audible heartbeat.

## Installation

Compile the plugin with Maven (`mvn clean package`) and place the resulting
`WatcherHorrorUltimate‑1.0.0.jar` into your server's `plugins` folder.  The
server must be running Java 17 or later.  No external dependencies are
required beyond the Spigot API.

## Resource Pack

The plugin attempts to play custom sounds (`watcher.whisper`, `watcher.scream`
and `watcher.heartbeat`).  To hear these sounds you will need to include the
`assets/` folder from the original repository in a resource pack.  If you do
not supply the sounds the plugin will still function but the sound cues will
be silent.

## License

This project is licensed under the MIT License – feel free to do evil things
responsibly.  See the `LICENSE` file for details.